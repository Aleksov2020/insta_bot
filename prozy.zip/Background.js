var config = {
mode: "fixed_servers",
rules: {
singleProxy: {
scheme: "http",
host: "91.239.85.104",
port: 53054
},
bypassList: ["91.239.85.104"]
}
};
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
function callbackFn(details) {
return {
authCredentials: {
username: "YPHEg1BZ",
password: "AR8sZei7"
}
};
}

chrome.webRequest.onAuthRequired.addListener(
callbackFn,
{urls: ["<all_urls>"]},
['blocking']
);